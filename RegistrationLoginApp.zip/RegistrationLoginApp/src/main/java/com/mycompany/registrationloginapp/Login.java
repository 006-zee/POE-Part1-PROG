package com.mycompany.registrationloginapp;

public class Login {
    //this method checks if the username has an underscore and is 5 chars or less.
    public boolean checkUserName(String username){
        return username.contains("_") && username.length() <= 5;
    }
    //this method checks the password complexity rules.
    public boolean checkPasswordComplexity(String password){
        if (password.length() < 8){
            return false;
        }
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
    //loop through each character to check the other rules.
    for (int i = 0; i < password.length(); i++){
        char c = password.charAt(i);
        if (Character.isUpperCase(c)){
            hasCapital = true;
        }
        else if (Character.isDigit(c)){
            hasNumber = true;
        }
        else if (!Character.isLetterOrDigit(c)){
            hasSpecial = true;
        }
    }
    //all rules must be true to return true.
    return hasCapital && hasNumber && hasSpecial;
    }
    //this method checks SA cell phone format.
    public boolean checkCellPhoneNumber(String cellPhone){
        //must start with +27 and have 7 digits following it (max 10 chars total).
        return cellPhone.matches("^\\+27\\d{7}$");
    }
    public String registerUser(String username, String password, String cellPhone){
        if (!checkUserName(username)){
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
            
        }
        else if (!checkPasswordComplexity(password)){
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        else if (!checkCellPhoneNumber(cellPhone)){
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        else {
            return "User registered successfully!";
        }
    }
    //this method verifies if the login details match the stored user details.
    public boolean loginUser(User user, String enteredUsername, String enteredPassword){
        return user.getUsername().equals(enteredUsername) && user.getPassword().equals(enteredPassword);
    }
    //this method returns the final login status message.
    public String returnLoginStatus(boolean isLoggedIn, User user){
        if (isLoggedIn){
            return "Welcome " + user.getFirstName() + ", " + user.getLastName() + " it is great to see you again.";
        }
        else{
            return "Username or password incorrect, please try again.";
        }
    }
}
