package com.mycompany.registrationloginapp;

//i import Scanner so i can get input from the user in the console.
import java.util.Scanner;

public class RegistrationLoginApp {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //i create an object of my login class so i can use its validation methods.
        Login loginSystem = new Login();
      
        System.out.println("----Registration----");
        
//1. get user's names.
System.out.println("Enter your First Name: ");
String firstName = input.nextLine();
        System.out.println("Enter your Last Name: ");
        String lastName = input.nextLine();
        
//2. username validation 
String username = "";
boolean isUsernameValid = false;
while (!isUsernameValid){
    
    System.out.println("Enter a username (must contain '_' and be <= 5 characters): ");
    username = input.nextLine();
    
    if (loginSystem.checkUserName(username)){
        System.out.println("Username succesfully captured.");
        isUsernameValid = true;
        
    }
    else {
        System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
    }
}
//3.password validation
String password = "";
boolean isPasswordValid = false;
while (!isPasswordValid){
    System.out.println("Enter a password (8+ chars, 1 Capital, 1 Number, 1 Special): ");
    password = input.nextLine();
    
    if (loginSystem.checkPasswordComplexity(password)){
        System.out.println("Password successfully captured.");
        isPasswordValid = true;
    }
    else{
        System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
    }
}
//4.cell phone validation
String cellPhone = "";
boolean isPhoneValid = false;
while (!isPhoneValid){
    System.out.println("Enter SA Cell Phone (e.g., +278212345): ");
    cellPhone = input.nextLine();
    
    if (loginSystem.checkCellPhoneNumber(cellPhone)){
        System.out.println("Cell phone number successfully added.");
        isPhoneValid = true;
    }
    else{
        System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
    }
}
//5.register the user
//since all data is valid, i create my User object now using the Constructor.
User newUser = new User(firstName, lastName, username, password, cellPhone);

String registrationMessage = loginSystem.registerUser(username, password, cellPhone);
        System.out.println(registrationMessage);
        
        //login feature
        System.out.println("\n----Login----");
        System.out.println("Enter your Username: ");
        String loginUsername = input.nextLine();
        System.out.println("Enter your Password: ");
        String loginPassword = input.nextLine();
        
       //check if the entered details match the stored User object.
       boolean isLoggedIn = loginSystem.loginUser(newUser, loginUsername, loginPassword);
       
       //final message
       String loginStatus = loginSystem.returnLoginStatus(isLoggedIn, newUser);
        System.out.println(loginStatus);
        
        input.close();
}}
        

