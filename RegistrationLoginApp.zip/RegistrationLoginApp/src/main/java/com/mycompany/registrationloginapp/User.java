package com.mycompany.registrationloginapp;

//i created this User class as a blueprint. It shows OOP encapsulation.
public class User {
    
    //all fields private so that other classes cannot change it directly.
    
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhoneNumber;
    
    //a constructor to set up the user once all their details are validated.
    public User(String firstName, String lastName, String username, String password, String cellPhoneNumber){
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }
    
    //getter methods that allows other classes to read the stored data safely.
    public String getFirstName(){ return firstName; }
    public String getLastName() { return lastName; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getCellPhoneNumber() { return cellPhoneNumber; }
}
