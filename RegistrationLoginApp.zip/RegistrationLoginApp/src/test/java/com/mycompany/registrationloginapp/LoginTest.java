package com.mycompany.registrationloginapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * these are my unit tests for the Login class.
 * they test that all validation rules work correctly.
 */
public class LoginTest {
Login login = new Login();

//test 1 username is correctly formatted.
@Test
public void testLoginSuccessful(){
    User user = new User ("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
    String expectedMessage = "Welcome Kyle, Smith it is great to see you again.";
    String actualMessage = login.returnLoginStatus(true, user);
    
    assertEquals(expectedMessage, actualMessage);
}
//test 2 username incorrectly formatted.
@Test
public void testUsernameIncorrectlyFormatted(){
    String expectedMessage = "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
    String actualMessage = login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99", "+27838968976");
    
    assertEquals(expectedMessage, actualMessage);
}

//test 3 password meets complexity requirements
@Test
public void testPasswordMeetsComplexity(){
    String actualMessage = login.registerUser("kyl_1", "Ch&&sec@ke99", "+27838968976");
    assertFalse(actualMessage.contains("Password successfully captured."));
}

//test 4 password does not meet complexity requirements
@Test
public void testPasswordDoesNotMeetComplexity(){
    String expectedMessage = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
    String actualMessage = login.registerUser("kyl_1", "password", "+27838968976");
    
    assertEquals(expectedMessage, actualMessage);
}

//test 5 cell phone correctly formatted
@Test
public void testCellPhoneCorrectlyFormatted(){
    String actualMessage = login.registerUser("kyl_1", "Ch&&sec@ke99", "+27838968976");
    assertFalse(actualMessage.contains("Cell phone number successfully added."));
}

//test 6 incorrectly formatted
@Test
public void testCellPhoneIncorrectlyFormatted(){
    String expectedMessage = "Cell phone number incorrectly formatted or does not contain international code.";
    String actualMessage = login.registerUser("kyl_1", "Ch&&sec@ke99", "08966553");
    assertEquals(expectedMessage, actualMessage);
}

//test 7 login successful
@Test
public void testLoginUserReturnsTrue(){
    User user = new User("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99", "+27838968976");
    assertTrue(login.loginUser(user, "kyl_1", "Ch&&sec@ke99"));
}

//test 8 is the log-in field.
@Test
public void tetsLoginUserReturnsFalse(){
    User user = new User("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99", "+27838968976");
    assertFalse(login.loginUser(user, "kyl_1", "wrongpassword"));
}

//test 9 username correctly formatted.
@Test
public void testUsernameCorrectlyFormatted(){
    assertTrue(login.checkUserName("kyl_1"));
}

//test 10 username incorrectly formatted.
@Test
public void testUsernameIncorrectlyFormattedBoolean(){
    assertFalse(login.checkUserName("kyle!!!!!!!"));
}

//test 11 password meets complexity.
@Test
public void testPasswordMeetsComplexityBoolean(){
    assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
}
//test 12 password does not meet complexity.
@Test
public void testPasswordDoesNotMeetComplexityBoolean(){
    assertFalse(login.checkPasswordComplexity("password"));
}

//test 13 cell phone correctly formatted (boolean)
@Test
public void testCellPhoneCorrectlyFormattedBoolean(){
    assertFalse(login.checkCellPhoneNumber("+27838968967"));
}

//test 14 incorrectly formatted cellphone.
@Test
public void testCellPhoneIncorrectlyFormattedBoolean(){
    assertFalse(login.checkCellPhoneNumber("08966553"));
}
}

    

    
  
